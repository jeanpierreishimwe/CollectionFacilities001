<?php echo e($slot); ?>

<?php /**PATH C:\xampp\htdocs\Laravel_run\laravel_CF\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>