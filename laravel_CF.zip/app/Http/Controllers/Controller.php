<?php

namespace App\Http\Controllers;

use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Routing\Controller as BaseController;

/**
* @OA\Info(
 * title="Collectional Facilities BaCK-End Rest Api EndPoints For",
 *      version="1.0.0",
 *     @OA\License(
 *         name="Apache 2.0",
 *         url="https://www.apache.org/licenses/LICENSE-2.0.html"
 *     )
 * )*/
class Controller extends BaseController
{
    use AuthorizesRequests, ValidatesRequests;
}
