<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Facilities;


class RegisterFacilitiesController extends Controller
{
    public function StoreFacilit(){
        //
    }

    public function UpdateOrEditFacilit(){
        //
    }

    public function DeleteFacilit(){
        //
    }
}
