<?php

namespace App\Http\Controllers;
use App\Models\User;
use App\Models\VisitationRequest;
use Illuminate\Http\Request;

class VisitationRequestController extends Controller
{
    public function SendRequest(){
        //
    }

    public function UpdateOrEditRequest(){
         //
    }

    public function DeleteRequest(){
        //
    }



}
